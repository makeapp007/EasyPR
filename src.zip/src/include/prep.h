//prep
#include "global.h"

#include <stdio.h>
#include <math.h>
#include <string.h>

#include "type.h"

