//debug

int Init(RGBPoint *mat);
int ADIInit(RGBPoint *mat,char matyuv[480][640][2]);
int PrintRGBMat(RGBPoint *mat,char name[]);
int PrintAMat(APoint *mat,char name[]);
int PrintMat(Point *mat,char name[]);