//global

#include "../include/global.h"

const double SobleModuleX[3][3]={{-1,0,1},{-2,0,2},{-1,0,1}};
const double SobleModuleY[3][3]={{-1,-2,-1},{0,0,0},{1,2,1}};