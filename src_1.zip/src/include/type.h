//Type Defignation

typedef struct RGBPoint{double r, g, b;} RGBPoint;
typedef double APoint;
typedef double Point;

typedef RGBPoint RGBMat[MAT_HEIGHT][MAT_WIDTH];
typedef APoint AMat[MAT_HEIGHT][MAT_WIDTH];
typedef Point Mat[MAT_HEIGHT][MAT_WIDTH];
